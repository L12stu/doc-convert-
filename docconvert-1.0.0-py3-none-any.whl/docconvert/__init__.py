"""Document conversion service."""

__version__ = "1.0.0"
