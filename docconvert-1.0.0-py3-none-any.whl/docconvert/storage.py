import shutil
from pathlib import Path

from .config import Settings
from .errors import ConversionError


class LocalStorage:
    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        path = (self.root / key).resolve()
        if path != self.root and self.root not in path.parents:
            raise ConversionError("UNSAFE_STORAGE_KEY", "非法存储路径", 500)
        return path

    def put(self, key: str, source: Path) -> None:
        destination = self._path(key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    def fetch(self, key: str, destination: Path) -> None:
        source = self._path(key)
        if not source.is_file():
            raise ConversionError("SOURCE_NOT_FOUND", "任务源文件不存在或已过期", 410)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)

    def download_location(self, key: str) -> tuple[str, str]:
        path = self._path(key)
        if not path.is_file():
            raise ConversionError("RESULT_NOT_FOUND", "结果文件不存在或已过期", 410)
        return "path", str(path)


class S3Storage:
    def __init__(self, settings: Settings) -> None:
        if not settings.s3_bucket:
            raise ConversionError("S3_NOT_CONFIGURED", "使用 S3 存储时必须配置 bucket", 500)
        import boto3

        self.bucket = settings.s3_bucket
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.s3_endpoint_url,
            region_name=settings.s3_region,
        )

    def put(self, key: str, source: Path) -> None:
        self.client.upload_file(str(source), self.bucket, key)

    def fetch(self, key: str, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        self.client.download_file(self.bucket, key, str(destination))

    def download_location(self, key: str) -> tuple[str, str]:
        url = self.client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": key},
            ExpiresIn=900,
        )
        return "url", url


def create_storage(settings: Settings) -> LocalStorage | S3Storage:
    if settings.storage_backend == "s3":
        return S3Storage(settings)
    return LocalStorage(settings.local_storage_dir)
