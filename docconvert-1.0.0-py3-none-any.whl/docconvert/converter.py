import logging
import shutil
import subprocess
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from .config import Settings
from .errors import ConversionError
from .formats import MEDIA_TYPES, Format

logger = logging.getLogger(__name__)


@dataclass
class ConversionResult:
    path: Path
    media_type: str
    warnings: list[str] = field(default_factory=list)


class ConversionEngine:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    @staticmethod
    def requires_libreoffice(source_format: Format, target_format: Format) -> bool:
        if target_format == Format.PDF:
            return source_format != Format.PDF
        if target_format in {Format.DOC, Format.ODT, Format.RTF}:
            return True
        return (
            source_format in {Format.DOC, Format.ODT, Format.RTF} and target_format != source_format
        )

    def convert(
        self,
        source: Path,
        source_format: Format,
        target_format: Format,
        workspace: Path,
    ) -> ConversionResult:
        if source_format == target_format:
            raise ConversionError("SAME_FORMAT", "输入与输出格式相同，无需转换", 400)
        output_dir = workspace / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        warnings = []
        if source_format == Format.PDF:
            self._require_digital_text(source)
            warnings.append("PDF 逆向转换属于版式重建；多栏、浮动对象和复杂表格需人工复核")
        if target_format in {Format.MD, Format.TXT}:
            warnings.append("Markdown/TXT 保留语义结构，不保留原页面尺寸和精确坐标")

        if target_format == Format.PDF:
            docx = self._to_docx(source, source_format, workspace)
            result = self._libreoffice(docx, Format.PDF, output_dir / "result")
        elif target_format == Format.DOCX:
            result = self._to_docx(source, source_format, workspace)
        elif target_format == Format.MD:
            result = self._to_markdown(source, source_format, output_dir)
            result = self._markdown_result(result, output_dir, warnings)
            self._validate_result(result.path)
            return result
        elif target_format == Format.HTML:
            result = self._to_html(source, source_format, workspace)
        elif target_format == Format.TXT:
            result = self._to_text(source, source_format, workspace)
        else:
            docx = self._to_docx(source, source_format, workspace)
            result = self._libreoffice(docx, target_format, output_dir / "result")

        self._validate_result(result)
        return ConversionResult(result, MEDIA_TYPES[target_format], warnings)

    def _validate_result(self, result_path: Path) -> None:
        self._ensure_output(result_path)
        if result_path.stat().st_size > self.settings.max_output_size:
            raise ConversionError(
                "OUTPUT_TOO_LARGE",
                f"转换结果超过 {self.settings.max_output_size // 1024 // 1024} MiB 上限",
                413,
            )

    def _to_docx(self, source: Path, source_format: Format, workspace: Path) -> Path:
        if source_format == Format.DOCX:
            return source
        destination_dir = workspace / "normalized"
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination = destination_dir / "normalized.docx"
        if source_format == Format.PDF:
            self._pdf_to_docx(source, destination)
            return destination
        if source_format in {Format.DOC, Format.ODT, Format.RTF}:
            return self._libreoffice(source, Format.DOCX, destination_dir / "normalized")
        if source_format == Format.TXT:
            self._text_to_docx(source, destination)
            return destination
        reader = "gfm" if source_format == Format.MD else "html"
        return self._pandoc(source, "docx", destination, reader=reader)

    def _to_markdown(self, source: Path, source_format: Format, output_dir: Path) -> Path:
        destination = output_dir / "result.md"
        if source_format == Format.PDF:
            return self._pdf_to_markdown(source, output_dir)
        if source_format == Format.TXT:
            destination.write_text(
                source.read_text(encoding="utf-8-sig", errors="replace"), encoding="utf-8"
            )
            return destination
        reader = {Format.DOCX: "docx"}.get(source_format)
        if source_format == Format.HTML:
            source = self._to_docx(source, source_format, output_dir.parent)
            reader = "docx"
        if reader is None:
            normalized = self._to_docx(source, source_format, output_dir.parent)
            source = normalized
            reader = "docx"
        return self._pandoc(
            source,
            "gfm",
            destination,
            reader=reader,
            extract_media=output_dir / "assets",
        )

    def _to_html(self, source: Path, source_format: Format, workspace: Path) -> Path:
        destination = workspace / "output" / "result.html"
        if source_format == Format.PDF:
            markdown = self._pdf_to_markdown(source, workspace / "pdf-markdown")
            return self._pandoc(markdown, "html", destination, reader="gfm", standalone=True)
        if source_format == Format.MD:
            return self._pandoc(source, "html", destination, reader="gfm", standalone=True)
        docx = self._to_docx(source, source_format, workspace)
        return self._pandoc(docx, "html", destination, reader="docx", standalone=True)

    def _to_text(self, source: Path, source_format: Format, workspace: Path) -> Path:
        destination = workspace / "output" / "result.txt"
        if source_format == Format.PDF:
            import fitz

            with fitz.open(source) as document:
                text = "\n\n".join(page.get_text("text", sort=True) for page in document)
            destination.write_text(text, encoding="utf-8")
            return destination
        reader = {Format.DOCX: "docx", Format.MD: "gfm", Format.HTML: "html"}.get(source_format)
        if reader is None:
            source = self._to_docx(source, source_format, workspace)
            reader = "docx"
        return self._pandoc(source, "plain", destination, reader=reader)

    def _pdf_to_docx(self, source: Path, destination: Path) -> None:
        try:
            from pdf2docx import Converter

            converter = Converter(str(source))
            try:
                converter.convert(str(destination))
            finally:
                converter.close()
        except ConversionError:
            raise
        except Exception as exc:
            logger.exception("PDF to DOCX failed")
            raise ConversionError(
                "PDF_RECONSTRUCTION_FAILED", "PDF 无法重建为 Word；请检查是否为损坏或扫描件"
            ) from exc
        self._ensure_output(destination)

    def _pdf_to_markdown(self, source: Path, output_dir: Path) -> Path:
        import pymupdf4llm

        output_dir.mkdir(parents=True, exist_ok=True)
        assets = output_dir / "assets"
        assets.mkdir(exist_ok=True)
        destination = output_dir / "result.md"
        try:
            markdown = pymupdf4llm.to_markdown(
                str(source),
                write_images=True,
                image_path=str(assets),
                image_format="png",
            )
        except Exception as exc:
            logger.exception("PDF to Markdown failed")
            raise ConversionError("PDF_EXTRACTION_FAILED", "PDF 文本或图片提取失败") from exc
        for path_variant in (str(assets), str(assets).replace("\\", "/")):
            markdown = markdown.replace(path_variant + "\\", "assets/")
            markdown = markdown.replace(path_variant + "/", "assets/")
        destination.write_text(markdown, encoding="utf-8")
        return destination

    @staticmethod
    def _require_digital_text(source: Path) -> None:
        import fitz

        with fitz.open(source) as document:
            text_length = sum(len(page.get_text().strip()) for page in document)
            if text_length < max(20, document.page_count * 2):
                raise ConversionError(
                    "OCR_REQUIRED",
                    "未检测到足够文本，可能是扫描件；请先启用外部 OCR 预处理",
                    422,
                )

    @staticmethod
    def _text_to_docx(source: Path, destination: Path) -> None:
        from docx import Document

        document = Document()
        text = source.read_text(encoding="utf-8-sig", errors="replace")
        for line in text.splitlines():
            document.add_paragraph(line)
        document.save(destination)

    def _pandoc(
        self,
        source: Path,
        target: str,
        destination: Path,
        reader: str,
        extract_media: Path | None = None,
        standalone: bool = False,
    ) -> Path:
        pandoc = self._pandoc_binary()
        destination.parent.mkdir(parents=True, exist_ok=True)
        command = [
            pandoc,
            str(source),
            f"--from={reader}",
            f"--to={target}",
            f"--resource-path={source.parent}",
            "--wrap=none",
            f"--output={destination}",
        ]
        if extract_media:
            command.append(f"--extract-media={extract_media}")
        if standalone:
            command.extend(["--standalone", "--embed-resources"])
        if target == "docx" and self.settings.reference_docx:
            command.append(f"--reference-doc={self.settings.reference_docx}")
        self._run(command, "Pandoc")
        if extract_media and destination.exists():
            content = destination.read_text(encoding="utf-8")
            for path_variant in (str(extract_media), str(extract_media).replace("\\", "/")):
                content = content.replace(path_variant + "\\", "assets/")
                content = content.replace(path_variant + "/", "assets/")
            destination.write_text(content, encoding="utf-8")
        return destination

    def _libreoffice(self, source: Path, target: Format, output_prefix: Path) -> Path:
        binary = (
            self.settings.libreoffice_path or shutil.which("soffice") or shutil.which("libreoffice")
        )
        if not binary:
            raise ConversionError(
                "LIBREOFFICE_UNAVAILABLE",
                "LibreOffice 未安装，无法执行该高保真版式转换",
                503,
                True,
            )
        output_dir = output_prefix.parent / f"{output_prefix.name}-{target.value}"
        profile = output_prefix.parent / f"lo-profile-{target.value}"
        output_dir.mkdir(parents=True, exist_ok=True)
        profile.mkdir(parents=True, exist_ok=True)
        filters = {
            Format.PDF: "writer_pdf_Export",
            Format.DOCX: "Office Open XML Text",
            Format.DOC: "MS Word 97",
            Format.ODT: "writer8",
            Format.RTF: "Rich Text Format",
        }
        command = [
            binary,
            f"-env:UserInstallation={profile.as_uri()}",
            "--headless",
            "--nologo",
            "--nodefault",
            "--nolockcheck",
            "--nofirststartwizard",
            "--convert-to",
            f"{target.value}:{filters[target]}",
            "--outdir",
            str(output_dir),
            str(source),
        ]
        self._run(command, "LibreOffice")
        destination = output_dir / f"{source.stem}.{target.value}"
        self._ensure_output(destination)
        return destination

    def _pandoc_binary(self) -> str:
        if self.settings.pandoc_path:
            return self.settings.pandoc_path
        if binary := shutil.which("pandoc"):
            return binary
        try:
            import pypandoc

            return str(pypandoc.get_pandoc_path())
        except (ImportError, OSError) as exc:
            raise ConversionError("PANDOC_UNAVAILABLE", "Pandoc 未安装", 503, True) from exc

    def _run(self, command: list[str], engine: str) -> None:
        try:
            process = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.settings.conversion_timeout,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise ConversionError(
                "CONVERSION_TIMEOUT",
                f"{engine} 转换超过 {self.settings.conversion_timeout} 秒",
                422,
                True,
            ) from exc
        except OSError as exc:
            raise ConversionError("ENGINE_START_FAILED", f"{engine} 无法启动", 503, True) from exc
        if process.returncode != 0:
            logger.error(
                "%s failed with code %s: %s", engine, process.returncode, process.stderr[-2000:]
            )
            raise ConversionError("ENGINE_FAILED", f"{engine} 无法转换该文档，请检查内容是否损坏")

    @staticmethod
    def _ensure_output(path: Path) -> None:
        if not path.is_file() or path.stat().st_size == 0:
            raise ConversionError("EMPTY_OUTPUT", "转换引擎未生成有效结果", 422)

    def _markdown_result(
        self, markdown: Path, output_dir: Path, warnings: list[str]
    ) -> ConversionResult:
        self._ensure_output(markdown)
        assets = output_dir / "assets"
        if not assets.exists() or not any(item.is_file() for item in assets.rglob("*")):
            return ConversionResult(markdown, MEDIA_TYPES[Format.MD], warnings)
        archive_path = output_dir / "result-md.zip"
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.write(markdown, "document.md")
            for item in assets.rglob("*"):
                if item.is_file():
                    archive.write(item, str(item.relative_to(output_dir)))
        return ConversionResult(archive_path, "application/zip", warnings)
