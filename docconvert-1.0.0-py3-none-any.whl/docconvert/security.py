import re
import zipfile
from pathlib import Path, PurePosixPath

from defusedxml import DefusedXmlException
from defusedxml.ElementTree import fromstring as parse_xml

from .config import Settings
from .errors import ConversionError
from .formats import Format

_REMOTE_RESOURCE = re.compile(r"(?:(?:https?|file|ftp):|^//)", re.IGNORECASE)
_MARKDOWN_IMAGE = re.compile(r"!\[[^\]]*\]\(([^)]+)\)")
_MARKDOWN_REFERENCE_IMAGE = re.compile(r"!\[[^\]]*\]\[([^\]]*)\]")
_MARKDOWN_DEFINITION = re.compile(r"^\s*\[([^\]]+)\]:\s*(\S+)", re.MULTILINE)
_HTML_SOURCE = re.compile(r"src=[\"']([^\"']+)[\"']", re.IGNORECASE)
_HTML_LINK = re.compile(r"<link\b[^>]*\bhref=[\"']([^\"']+)[\"']", re.IGNORECASE)


def safe_filename(filename: str | None) -> str:
    name = Path(filename or "document").name
    name = "".join(char for char in name if char.isprintable() and char not in '<>:"/\\|?*')
    return name[:180] or "document"


def safe_asset_path(filename: str) -> str:
    normalized = filename.replace("\\", "/")
    path = PurePosixPath(normalized)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts) or not path.parts:
        raise ConversionError("UNSAFE_ASSET_PATH", "资源文件路径不能为绝对路径或包含 ..", 400)
    safe_parts = [safe_filename(part) for part in path.parts]
    return str(PurePosixPath(*safe_parts))


def validate_upload(path: Path, source_format: Format, settings: Settings) -> None:
    size = path.stat().st_size
    if size == 0:
        raise ConversionError("EMPTY_FILE", "不能转换空文件", 400)
    if size > settings.max_file_size:
        raise ConversionError(
            "FILE_TOO_LARGE",
            f"单文件上限为 {settings.max_file_size // 1024 // 1024} MiB",
            413,
        )
    if source_format in {Format.DOCX, Format.ODT}:
        _validate_archive(path, settings)
    if source_format == Format.PDF:
        _validate_pdf(path, settings)
    if source_format in {Format.MD, Format.HTML, Format.TXT}:
        _validate_text_resources(path, source_format)


def _validate_archive(path: Path, settings: Settings) -> None:
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > settings.max_archive_entries:
                raise ConversionError("ARCHIVE_TOO_COMPLEX", "文档内部文件数量超过限制", 413)
            total = sum(entry.file_size for entry in entries)
            if total > settings.max_uncompressed_size:
                raise ConversionError("ARCHIVE_TOO_LARGE", "文档解压后大小超过限制", 413)
            for entry in entries:
                if entry.flag_bits & 0x1:
                    raise ConversionError("ENCRYPTED_DOCUMENT", "不支持加密 Office 文档", 422)
                if (
                    entry.compress_size
                    and entry.file_size / entry.compress_size > settings.max_compression_ratio
                ):
                    raise ConversionError("ZIP_BOMB", "文档压缩比异常，已拒绝处理", 422)
                if entry.filename.endswith(".rels"):
                    _reject_external_images(archive.read(entry.filename))
    except ConversionError:
        raise
    except (zipfile.BadZipFile, DefusedXmlException, RuntimeError) as exc:
        raise ConversionError("CORRUPT_DOCUMENT", "Office 文档结构损坏或无法解析", 422) from exc


def _reject_external_images(content: bytes) -> None:
    root = parse_xml(content)
    for relationship in root:
        if (
            relationship.attrib.get("Type", "").endswith("/image")
            and relationship.attrib.get("TargetMode", "").lower() == "external"
        ):
            raise ConversionError(
                "REMOTE_RESOURCE_BLOCKED",
                "为防止 SSRF，不处理引用外部图片的文档；请先内嵌图片",
                422,
            )


def _validate_pdf(path: Path, settings: Settings) -> None:
    import fitz

    try:
        with fitz.open(path) as document:
            if document.needs_pass or document.is_encrypted:
                raise ConversionError("ENCRYPTED_PDF", "请先移除 PDF 密码再转换", 422)
            if document.page_count == 0:
                raise ConversionError("EMPTY_DOCUMENT", "PDF 没有页面", 422)
            if document.page_count > settings.max_pdf_pages:
                raise ConversionError(
                    "TOO_MANY_PAGES",
                    f"PDF 页数上限为 {settings.max_pdf_pages}",
                    413,
                )
    except ConversionError:
        raise
    except Exception as exc:
        raise ConversionError("CORRUPT_PDF", "PDF 损坏或结构不受支持", 422) from exc


def _validate_text_resources(path: Path, source_format: Format) -> None:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    references = []
    if source_format == Format.MD:
        references = _MARKDOWN_IMAGE.findall(text) + _HTML_SOURCE.findall(text)
        definitions = {
            label.lower(): target for label, target in _MARKDOWN_DEFINITION.findall(text)
        }
        for label in _MARKDOWN_REFERENCE_IMAGE.findall(text):
            if label.lower() in definitions:
                references.append(definitions[label.lower()])
    elif source_format == Format.HTML:
        references = _HTML_SOURCE.findall(text) + _HTML_LINK.findall(text)
    if any(_REMOTE_RESOURCE.search(reference.strip()) for reference in references):
        raise ConversionError(
            "REMOTE_RESOURCE_BLOCKED",
            "为防止 SSRF，远程图片和 file:// 资源不会自动下载；请随文件上传资源",
            422,
        )
