import hashlib
import json
import logging
import time
import uuid
from datetime import UTC, datetime

from redis import Redis
from rq import Queue
from rq.command import send_stop_job_command
from rq.job import Job

from .config import Settings
from .errors import ConversionError
from .formats import Format
from .security import safe_filename
from .storage import LocalStorage, S3Storage

logger = logging.getLogger(__name__)


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def decode_hash(values: dict) -> dict[str, str]:
    return {
        key.decode() if isinstance(key, bytes) else key: value.decode()
        if isinstance(value, bytes)
        else value
        for key, value in values.items()
    }


class JobService:
    def __init__(self, redis: Redis, storage: LocalStorage | S3Storage, settings: Settings) -> None:
        self.redis = redis
        self.storage = storage
        self.settings = settings
        self.queue = Queue(settings.queue_name, connection=redis)

    @staticmethod
    def job_key(job_id: str) -> str:
        return f"docconvert:job:{job_id}"

    def create_job(
        self,
        filename: str,
        source_path,
        source_format: Format,
        target_format: Format,
        content_sha256: str,
        assets: list[tuple[str, object]] | None = None,
        idempotency_key: str | None = None,
        owner: str = "anonymous",
    ) -> tuple[dict[str, str], bool]:
        if self.queue.count >= self.settings.max_queue_depth:
            raise ConversionError("QUEUE_FULL", "转换队列已满，请稍后重试", 503, True)
        job_id = str(uuid.uuid4())
        idem_redis_key = None
        idem_value = f"{job_id}:{content_sha256}"
        if idempotency_key:
            digest = hashlib.sha256(f"{owner}:{idempotency_key}".encode()).hexdigest()
            idem_redis_key = f"docconvert:idem:{digest}"
            if not self.redis.set(idem_redis_key, idem_value, nx=True, ex=self.settings.job_ttl):
                existing = self.redis.get(idem_redis_key)
                existing = existing.decode() if isinstance(existing, bytes) else existing
                existing_job_id, _, existing_sha = (existing or "").partition(":")
                if existing_sha != content_sha256:
                    raise ConversionError(
                        "IDEMPOTENCY_CONFLICT",
                        "同一 Idempotency-Key 不能用于不同文件",
                        409,
                    )
                existing_job = self.get_job(existing_job_id, owner)
                if not existing_job:
                    raise ConversionError(
                        "IDEMPOTENCY_RETRY", "相同请求正在初始化，请稍后重试", 409, True
                    )
                if (
                    existing_sha != content_sha256
                    or existing_job["target_format"] != target_format.value
                ):
                    raise ConversionError(
                        "IDEMPOTENCY_CONFLICT",
                        "同一 Idempotency-Key 不能用于不同文件或目标格式",
                        409,
                    )
                return existing_job, True

        try:
            input_key = f"jobs/{job_id}/input.{source_format.value}"
            self.storage.put(input_key, source_path)
            asset_records = []
            for relative_path, asset_path in assets or []:
                key = f"jobs/{job_id}/assets/{relative_path}"
                self.storage.put(key, asset_path)
                asset_records.append({"key": key, "path": relative_path})
            metadata = {
                "id": job_id,
                "owner": owner,
                "status": "queued",
                "progress": "0",
                "filename": safe_filename(filename),
                "source_format": source_format.value,
                "target_format": target_format.value,
                "input_key": input_key,
                "assets": json.dumps(asset_records, ensure_ascii=False),
                "created_at": utc_now(),
                "created_ts": str(time.time()),
            }
            self.redis.hset(self.job_key(job_id), mapping=metadata)
            self.queue.enqueue(
                "docconvert.worker.run_conversion",
                job_id,
                job_id=job_id,
                job_timeout=self.settings.conversion_timeout + 30,
                result_ttl=self.settings.job_ttl,
                failure_ttl=self.settings.job_ttl,
            )
            return metadata, False
        except Exception:
            if idem_redis_key:
                self.redis.delete(idem_redis_key)
            raise

    def get_job(self, job_id: str, owner: str | None = None) -> dict[str, str]:
        values = self.redis.hgetall(self.job_key(job_id))
        job = decode_hash(values) if values else {}
        if owner is not None and job.get("owner") != owner:
            return {}
        return job

    def create_batch(self, jobs: list[dict], owner: str = "anonymous") -> dict:
        batch_id = str(uuid.uuid4())
        key = f"docconvert:batch:{batch_id}"
        job_ids = [item["job_id"] for item in jobs if item.get("job_id")]
        rejected = [item for item in jobs if item.get("status") == "rejected"]
        self.redis.hset(
            key,
            mapping={
                "id": batch_id,
                "owner": owner,
                "created_at": utc_now(),
                "rejected": json.dumps(rejected, ensure_ascii=False),
            },
        )
        if job_ids:
            self.redis.sadd(f"{key}:jobs", *job_ids)
        self.redis.expire(key, self.settings.job_ttl)
        self.redis.expire(f"{key}:jobs", self.settings.job_ttl)
        return {"batch_id": batch_id, "items": jobs}

    def get_batch(self, batch_id: str, owner: str | None = None) -> dict:
        key = f"docconvert:batch:{batch_id}"
        batch_metadata = decode_hash(self.redis.hgetall(key))
        if not batch_metadata or (owner is not None and batch_metadata.get("owner") != owner):
            return {}
        raw_ids = self.redis.smembers(f"{key}:jobs")
        job_ids = [item.decode() if isinstance(item, bytes) else item for item in raw_ids]
        jobs = [self.get_job(job_id, owner) for job_id in sorted(job_ids)]
        jobs = [job for job in jobs if job]
        summary = {status: 0 for status in ("queued", "running", "succeeded", "failed", "canceled")}
        for job in jobs:
            summary[job["status"]] = summary.get(job["status"], 0) + 1
        rejected = json.loads(batch_metadata.get("rejected", "[]"))
        summary["rejected"] = len(rejected)
        return {"batch_id": batch_id, "summary": summary, "jobs": jobs, "rejected": rejected}

    def cancel_job(self, job_id: str, owner: str | None = None) -> dict[str, str]:
        job = self.get_job(job_id, owner)
        if not job:
            raise ConversionError("JOB_NOT_FOUND", "任务不存在", 404)
        if job["status"] not in {"queued", "running"}:
            raise ConversionError("JOB_NOT_CANCELLABLE", "任务已结束，不能取消", 409)
        try:
            if job["status"] == "running":
                send_stop_job_command(self.redis, job_id)
            else:
                Job.fetch(job_id, connection=self.redis).cancel()
        except Exception:
            logger.warning(
                "Best-effort cancel for job %s failed; metadata remains authoritative", job_id
            )
        self.redis.hset(
            self.job_key(job_id),
            mapping={"status": "canceled", "finished_at": utc_now(), "error_code": "CANCELED"},
        )
        self.redis.expire(self.job_key(job_id), self.settings.job_ttl)
        return self.get_job(job_id)

    def reap_stale_jobs(self) -> int:
        count = 0
        threshold = time.time() - self.settings.conversion_timeout - self.settings.stale_job_grace
        for raw_key in self.redis.scan_iter(match="docconvert:job:*", count=200):
            values = decode_hash(self.redis.hgetall(raw_key))
            if values.get("status") != "running":
                continue
            if float(values.get("started_ts", time.time())) <= threshold:
                self.redis.hset(
                    raw_key,
                    mapping={
                        "status": "failed",
                        "error_code": "STALE_JOB",
                        "error_message": "工作进程中断，任务已被回收；请重新提交",
                        "finished_at": utc_now(),
                    },
                )
                self.redis.expire(raw_key, self.settings.job_ttl)
                count += 1
        return count
