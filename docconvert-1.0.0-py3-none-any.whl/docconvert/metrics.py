from prometheus_client import Counter, Histogram

CONVERSIONS = Counter(
    "docconvert_conversions_total",
    "Completed conversion jobs",
    ["source", "target", "status"],
)
CONVERSION_DURATION = Histogram(
    "docconvert_conversion_seconds",
    "Conversion engine duration, excluding queue wait",
    ["source", "target"],
    buckets=(0.25, 0.5, 1, 2, 5, 10, 30, 60, 120, 300),
)
QUEUE_DURATION = Histogram(
    "docconvert_queue_seconds",
    "Time spent waiting before conversion",
    buckets=(0.01, 0.1, 0.5, 1, 2, 5, 10, 30, 60, 300),
)
