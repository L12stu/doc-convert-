import hmac
from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="DOCCONVERT_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    redis_url: str = "redis://localhost:6379/0"
    queue_name: str = "conversion"
    storage_backend: str = "local"
    local_storage_dir: Path = Path("./data")
    s3_bucket: str = ""
    s3_endpoint_url: str | None = None
    s3_region: str = "us-east-1"

    max_file_size: int = 50 * 1024 * 1024
    max_batch_files: int = 20
    max_batch_size: int = 200 * 1024 * 1024
    max_queue_depth: int = 1000
    max_assets_per_file: int = 50
    max_pdf_pages: int = 300
    max_archive_entries: int = 2000
    max_uncompressed_size: int = 500 * 1024 * 1024
    max_output_size: int = 200 * 1024 * 1024
    max_compression_ratio: int = 200
    conversion_timeout: int = 120
    job_ttl: int = 24 * 60 * 60
    stale_job_grace: int = 60
    api_keys: str = ""

    pandoc_path: str | None = None
    libreoffice_path: str | None = None
    reference_docx: Path | None = None

    @field_validator("s3_endpoint_url", mode="before")
    @classmethod
    def empty_endpoint_to_none(cls, value: object) -> object:
        return None if value == "" else value

    def valid_api_key(self, candidate: str | None) -> bool:
        keys = {item.strip() for item in self.api_keys.split(",") if item.strip()}
        return not keys or any(hmac.compare_digest(candidate or "", key) for key in keys)


@lru_cache
def get_settings() -> Settings:
    return Settings()
