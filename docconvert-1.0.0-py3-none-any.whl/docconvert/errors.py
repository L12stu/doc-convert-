class ConversionError(Exception):
    """A stable, client-safe conversion error."""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 422,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retryable = retryable
