import zipfile
from enum import StrEnum
from pathlib import Path

from .errors import ConversionError


class Format(StrEnum):
    PDF = "pdf"
    DOCX = "docx"
    DOC = "doc"
    MD = "md"
    HTML = "html"
    ODT = "odt"
    RTF = "rtf"
    TXT = "txt"


EXTENSIONS = {
    ".pdf": Format.PDF,
    ".docx": Format.DOCX,
    ".doc": Format.DOC,
    ".md": Format.MD,
    ".markdown": Format.MD,
    ".html": Format.HTML,
    ".htm": Format.HTML,
    ".odt": Format.ODT,
    ".rtf": Format.RTF,
    ".txt": Format.TXT,
}

MEDIA_TYPES = {
    Format.PDF: "application/pdf",
    Format.DOCX: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    Format.DOC: "application/msword",
    Format.MD: "text/markdown; charset=utf-8",
    Format.HTML: "text/html; charset=utf-8",
    Format.ODT: "application/vnd.oasis.opendocument.text",
    Format.RTF: "application/rtf",
    Format.TXT: "text/plain; charset=utf-8",
}


def normalize_format(value: str) -> Format:
    normalized = value.lower().strip().lstrip(".")
    if normalized == "markdown":
        normalized = "md"
    if normalized == "htm":
        normalized = "html"
    try:
        return Format(normalized)
    except ValueError as exc:
        supported = ", ".join(item.value for item in Format)
        raise ConversionError(
            "UNSUPPORTED_FORMAT",
            f"不支持格式 {value!r}；可选值：{supported}",
            400,
        ) from exc


def detect_format(path: Path, filename: str) -> Format:
    suffix = Path(filename).suffix.lower()
    if suffix not in EXTENSIONS:
        raise ConversionError("UNSUPPORTED_FORMAT", f"不支持的文件扩展名：{suffix or '无'}", 415)
    expected = EXTENSIONS[suffix]
    with path.open("rb") as stream:
        header = stream.read(512)

    if expected == Format.PDF and not header.startswith(b"%PDF-"):
        raise ConversionError("FORMAT_MISMATCH", "文件内容不是有效 PDF", 415)
    if expected == Format.DOC and not header.startswith(bytes.fromhex("D0CF11E0A1B11AE1")):
        raise ConversionError("FORMAT_MISMATCH", "文件内容不是有效的旧版 Word 文档", 415)
    if expected == Format.RTF and not header.lstrip().startswith(b"{\\rtf"):
        raise ConversionError("FORMAT_MISMATCH", "文件内容不是有效 RTF", 415)
    if expected in {Format.DOCX, Format.ODT}:
        if not zipfile.is_zipfile(path):
            raise ConversionError("FORMAT_MISMATCH", f"文件内容不是有效 {expected.value}", 415)
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 10_000:
                raise ConversionError(
                    "ARCHIVE_TOO_COMPLEX", "文档内部文件数量异常，已拒绝处理", 413
                )
            names = {entry.filename for entry in entries}
        if expected == Format.DOCX and "word/document.xml" not in names:
            raise ConversionError("FORMAT_MISMATCH", "DOCX 缺少 word/document.xml", 415)
        if expected == Format.ODT and "content.xml" not in names:
            raise ConversionError("FORMAT_MISMATCH", "ODT 缺少 content.xml", 415)
    if expected == Format.HTML:
        prefix = header.lstrip().lower()
        if b"<html" not in prefix and b"<!doctype html" not in prefix:
            raise ConversionError("FORMAT_MISMATCH", "HTML 文件缺少 html 文档标记", 415)
    return expected
