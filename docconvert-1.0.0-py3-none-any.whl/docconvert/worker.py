import json
import logging
import tempfile
import time
from pathlib import Path

from prometheus_client import start_http_server
from redis import Redis
from rq import Queue, Worker

from .config import get_settings
from .converter import ConversionEngine
from .errors import ConversionError
from .formats import Format
from .jobs import JobService, decode_hash, utc_now
from .metrics import CONVERSION_DURATION, CONVERSIONS, QUEUE_DURATION
from .security import safe_filename
from .storage import create_storage

logger = logging.getLogger(__name__)


def run_conversion(job_id: str) -> None:
    settings = get_settings()
    redis = Redis.from_url(settings.redis_url)
    storage = create_storage(settings)
    service = JobService(redis, storage, settings)
    key = service.job_key(job_id)
    metadata = decode_hash(redis.hgetall(key))
    if not metadata:
        logger.error("Job %s has no metadata", job_id)
        return
    if metadata.get("status") == "canceled":
        return
    source_format = Format(metadata["source_format"])
    target_format = Format(metadata["target_format"])
    started = time.monotonic()
    redis.hset(
        key,
        mapping={
            "status": "running",
            "progress": "10",
            "started_at": utc_now(),
            "started_ts": time.time(),
        },
    )
    if created_ts := metadata.get("created_ts"):
        QUEUE_DURATION.observe(max(0, time.time() - float(created_ts)))

    try:
        with tempfile.TemporaryDirectory(prefix=f"docconvert-{job_id}-") as temporary:
            workspace = Path(temporary)
            input_dir = workspace / "input"
            source = input_dir / f"input.{source_format.value}"
            storage.fetch(metadata["input_key"], source)
            for asset in json.loads(metadata.get("assets", "[]")):
                storage.fetch(asset["key"], input_dir / asset["path"])
            result = ConversionEngine(settings).convert(
                source, source_format, target_format, workspace
            )
            current_status = redis.hget(key, "status")
            current_status = (
                current_status.decode() if isinstance(current_status, bytes) else current_status
            )
            if current_status == "canceled":
                return
            result_key = f"jobs/{job_id}/result{result.path.suffix}"
            storage.put(result_key, result.path)
            suffix = result.path.suffix
            result_name = f"{Path(safe_filename(metadata['filename'])).stem}-converted{suffix}"
            elapsed = time.monotonic() - started
            redis.hset(
                key,
                mapping={
                    "status": "succeeded",
                    "progress": "100",
                    "result_key": result_key,
                    "result_name": result_name,
                    "media_type": result.media_type,
                    "warnings": json.dumps(result.warnings, ensure_ascii=False),
                    "duration_ms": round(elapsed * 1000),
                    "finished_at": utc_now(),
                },
            )
            CONVERSION_DURATION.labels(source_format.value, target_format.value).observe(elapsed)
            CONVERSIONS.labels(source_format.value, target_format.value, "succeeded").inc()
    except ConversionError as exc:
        current_status = redis.hget(key, "status")
        current_status = (
            current_status.decode() if isinstance(current_status, bytes) else current_status
        )
        if current_status == "canceled":
            return
        redis.hset(
            key,
            mapping={
                "status": "failed",
                "error_code": exc.code,
                "error_message": exc.message,
                "retryable": str(exc.retryable).lower(),
                "finished_at": utc_now(),
            },
        )
        CONVERSIONS.labels(source_format.value, target_format.value, "failed").inc()
        raise
    except Exception:
        logger.exception("Unexpected conversion failure for job %s", job_id)
        current_status = redis.hget(key, "status")
        current_status = (
            current_status.decode() if isinstance(current_status, bytes) else current_status
        )
        if current_status == "canceled":
            return
        redis.hset(
            key,
            mapping={
                "status": "failed",
                "error_code": "INTERNAL_ERROR",
                "error_message": "转换服务内部错误，请稍后重新提交",
                "retryable": "true",
                "finished_at": utc_now(),
            },
        )
        CONVERSIONS.labels(source_format.value, target_format.value, "failed").inc()
        raise
    finally:
        redis.expire(key, settings.job_ttl)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    settings = get_settings()
    redis = Redis.from_url(settings.redis_url)
    start_http_server(9100)
    worker = Worker([Queue(settings.queue_name)], connection=redis)
    worker.work(with_scheduler=True)


if __name__ == "__main__":
    main()
