from redis import Redis

from .config import get_settings
from .jobs import JobService
from .storage import create_storage


def main() -> None:
    settings = get_settings()
    service = JobService(Redis.from_url(settings.redis_url), create_storage(settings), settings)
    count = service.reap_stale_jobs()
    print(f"Reaped {count} stale jobs")


if __name__ == "__main__":
    main()
