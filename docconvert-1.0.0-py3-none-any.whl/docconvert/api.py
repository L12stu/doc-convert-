import hashlib
import json
import shutil
import tempfile
import time
from functools import lru_cache
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, Header, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from redis import Redis

from . import __version__
from .config import Settings, get_settings
from .converter import ConversionEngine
from .errors import ConversionError
from .formats import Format, detect_format, normalize_format
from .jobs import JobService
from .security import safe_asset_path, safe_filename, validate_upload
from .storage import create_storage

app = FastAPI(
    title="DocConvert",
    version=__version__,
    description="Bounded, asynchronous PDF / Word / Markdown conversion API",
)

HTTP_REQUESTS = Counter(
    "docconvert_http_requests_total", "API requests", ["method", "route", "status"]
)
HTTP_DURATION = Histogram("docconvert_http_seconds", "API request duration", ["method", "route"])


def get_job_service() -> JobService:
    settings = get_settings()
    return JobService(Redis.from_url(settings.redis_url), create_storage(settings), settings)


get_job_service = lru_cache(maxsize=1)(get_job_service)


def authorize(
    x_api_key: str | None = Header(default=None), settings: Settings = Depends(get_settings)
) -> str:
    if not settings.valid_api_key(x_api_key):
        raise ConversionError("UNAUTHORIZED", "缺少或错误的 X-API-Key", 401)
    return hashlib.sha256((x_api_key or "anonymous").encode()).hexdigest()


@app.middleware("http")
async def observe_requests(request: Request, call_next):
    started = time.monotonic()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        route = request.scope.get("route")
        route_path = getattr(route, "path", "unmatched")
        HTTP_REQUESTS.labels(request.method, route_path, status).inc()
        HTTP_DURATION.labels(request.method, route_path).observe(time.monotonic() - started)


@app.exception_handler(ConversionError)
async def conversion_error_handler(_request: Request, exc: ConversionError) -> JSONResponse:
    headers = {"Retry-After": "5"} if exc.status_code == 503 else None
    return JSONResponse(
        status_code=exc.status_code,
        headers=headers,
        content={"error": {"code": exc.code, "message": exc.message, "retryable": exc.retryable}},
    )


async def save_upload(upload: UploadFile, destination: Path, limit: int) -> tuple[str, int]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    size = 0
    try:
        with destination.open("wb") as stream:
            while chunk := await upload.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    limit_mib = limit // 1024 // 1024
                    name = safe_filename(upload.filename)
                    raise ConversionError(
                        "FILE_TOO_LARGE",
                        f"文件 {name} 超过 {limit_mib} MiB 上限",
                        413,
                    )
                digest.update(chunk)
                stream.write(chunk)
    finally:
        await upload.close()
    if size == 0:
        raise ConversionError("EMPTY_FILE", f"文件 {safe_filename(upload.filename)} 为空", 400)
    return digest.hexdigest(), size


def public_job(job: dict[str, str]) -> dict:
    result = {
        key: job[key]
        for key in (
            "id",
            "status",
            "progress",
            "filename",
            "source_format",
            "target_format",
            "created_at",
            "started_at",
            "finished_at",
            "duration_ms",
        )
        if key in job
    }
    result["progress"] = int(result.get("progress", 0))
    if "duration_ms" in result:
        result["duration_ms"] = int(result["duration_ms"])
    if job.get("status") == "succeeded":
        result["result_name"] = job.get("result_name")
        result["media_type"] = job.get("media_type")
        result["download_url"] = f"/v1/jobs/{job['id']}/download"
        result["warnings"] = json.loads(job.get("warnings", "[]"))
    if job.get("status") == "failed":
        result["error"] = {
            "code": job.get("error_code"),
            "message": job.get("error_message"),
            "retryable": job.get("retryable") == "true",
        }
    if job.get("status") == "canceled":
        result["error"] = {"code": "CANCELED", "message": "任务已取消", "retryable": True}
    return result


def ensure_engine_available(
    source_format: Format, target_format: Format, settings: Settings
) -> None:
    if not ConversionEngine.requires_libreoffice(source_format, target_format):
        return
    binary = settings.libreoffice_path or shutil.which("soffice") or shutil.which("libreoffice")
    if not binary:
        raise ConversionError(
            "LIBREOFFICE_UNAVAILABLE",
            "LibreOffice 未安装，无法执行该高保真版式转换",
            503,
            True,
        )


@app.get("/")
def root() -> dict:
    return {"service": "DocConvert", "version": __version__, "docs": "/docs"}


@app.get("/v1/formats")
def formats() -> dict:
    values = [item.value for item in Format]
    return {
        "input": values + ["markdown", "htm"],
        "output": values,
        "rules": "任意两种不同格式均可路由转换；PDF 逆向和 Markdown 输出不承诺像素级还原",
        "max_file_mib": get_settings().max_file_size // 1024 // 1024,
        "max_pdf_pages": get_settings().max_pdf_pages,
        "max_batch_files": get_settings().max_batch_files,
    }


@app.post("/v1/conversions", status_code=202)
async def create_conversion(
    response: Response,
    file: UploadFile = File(...),
    target_format: str = Form(...),
    assets: list[UploadFile] | None = File(default=None),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
    service: JobService = Depends(get_job_service),
    settings: Settings = Depends(get_settings),
    owner: str = Depends(authorize),
) -> dict:
    target = normalize_format(target_format)
    asset_uploads = assets or []
    if len(asset_uploads) > settings.max_assets_per_file:
        raise ConversionError("TOO_MANY_ASSETS", "每个 Markdown 文档最多上传 50 个资源文件", 413)
    with tempfile.TemporaryDirectory(prefix="docconvert-upload-") as temporary:
        root = Path(temporary)
        source = root / safe_filename(file.filename)
        content_sha256, _ = await save_upload(file, source, settings.max_file_size)
        source_format = detect_format(source, file.filename or "")
        ensure_engine_available(source_format, target, settings)
        await run_in_threadpool(validate_upload, source, source_format, settings)
        if source_format == target:
            raise ConversionError("SAME_FORMAT", "输入与输出格式相同，无需转换", 400)
        saved_assets = []
        asset_budget = settings.max_file_size
        for index, asset in enumerate(asset_uploads):
            relative = safe_asset_path(asset.filename or f"asset-{index}")
            destination = root / "assets" / relative
            _, size = await save_upload(asset, destination, asset_budget)
            asset_budget -= size
            saved_assets.append((relative, destination))
        job, replayed = await run_in_threadpool(
            service.create_job,
            file.filename or source.name,
            source,
            source_format,
            target,
            content_sha256,
            saved_assets,
            idempotency_key,
            owner,
        )
    if replayed:
        response.status_code = 200
    result = public_job(job)
    result["idempotent_replay"] = replayed
    return result


@app.post("/v1/batches", status_code=202)
async def create_batch(
    files: list[UploadFile] = File(...),
    target_format: str = Form(...),
    service: JobService = Depends(get_job_service),
    settings: Settings = Depends(get_settings),
    owner: str = Depends(authorize),
) -> dict:
    if not files:
        raise ConversionError("EMPTY_BATCH", "批次不能为空", 400)
    if len(files) > settings.max_batch_files:
        raise ConversionError("TOO_MANY_FILES", f"每批最多 {settings.max_batch_files} 个文件", 413)
    target = normalize_format(target_format)
    items = []
    total_size = 0
    with tempfile.TemporaryDirectory(prefix="docconvert-batch-") as temporary:
        root = Path(temporary)
        for index, file in enumerate(files):
            try:
                source = root / str(index) / safe_filename(file.filename)
                content_sha256, size = await save_upload(file, source, settings.max_file_size)
                total_size += size
                if total_size > settings.max_batch_size:
                    raise ConversionError("BATCH_TOO_LARGE", "批次总大小超过 200 MiB 上限", 413)
                source_format = detect_format(source, file.filename or "")
                ensure_engine_available(source_format, target, settings)
                await run_in_threadpool(validate_upload, source, source_format, settings)
                if source_format == target:
                    raise ConversionError("SAME_FORMAT", "输入与输出格式相同", 400)
                job, _ = await run_in_threadpool(
                    service.create_job,
                    file.filename or source.name,
                    source,
                    source_format,
                    target,
                    content_sha256,
                    owner=owner,
                )
                items.append(
                    {"job_id": job["id"], "filename": job["filename"], "status": job["status"]}
                )
            except ConversionError as exc:
                items.append(
                    {
                        "filename": safe_filename(file.filename),
                        "status": "rejected",
                        "error": {"code": exc.code, "message": exc.message},
                    }
                )
    return await run_in_threadpool(service.create_batch, items, owner)


@app.get("/v1/jobs/{job_id}")
def job_status(
    job_id: str,
    service: JobService = Depends(get_job_service),
    owner: str = Depends(authorize),
) -> dict:
    job = service.get_job(job_id, owner)
    if not job:
        raise ConversionError("JOB_NOT_FOUND", "任务不存在或已过期", 404)
    return public_job(job)


@app.get("/v1/jobs/{job_id}/download")
def download(
    job_id: str,
    service: JobService = Depends(get_job_service),
    owner: str = Depends(authorize),
):
    job = service.get_job(job_id, owner)
    if not job:
        raise ConversionError("JOB_NOT_FOUND", "任务不存在或已过期", 404)
    if job.get("status") != "succeeded":
        raise ConversionError("JOB_NOT_READY", "任务尚未成功完成", 409)
    kind, location = service.storage.download_location(job["result_key"])
    if kind == "url":
        return RedirectResponse(location, status_code=303)
    return FileResponse(location, media_type=job["media_type"], filename=job["result_name"])


@app.delete("/v1/jobs/{job_id}")
def cancel(
    job_id: str,
    service: JobService = Depends(get_job_service),
    owner: str = Depends(authorize),
) -> dict:
    return public_job(service.cancel_job(job_id, owner))


@app.get("/v1/batches/{batch_id}")
def batch_status(
    batch_id: str,
    service: JobService = Depends(get_job_service),
    owner: str = Depends(authorize),
) -> dict:
    batch = service.get_batch(batch_id, owner)
    if not batch:
        raise ConversionError("BATCH_NOT_FOUND", "批次不存在或已过期", 404)
    batch["jobs"] = [public_job(job) for job in batch["jobs"]]
    return batch


@app.get("/health/live")
def live() -> dict:
    return {"status": "ok"}


@app.get("/health/ready")
def ready(service: JobService = Depends(get_job_service)) -> Response:
    try:
        service.redis.ping()
    except Exception:
        return JSONResponse(status_code=503, content={"status": "unavailable", "redis": "error"})
    settings = get_settings()
    try:
        pandoc = ConversionEngine(settings)._pandoc_binary()
    except ConversionError:
        pandoc = None
    libreoffice = (
        settings.libreoffice_path or shutil.which("soffice") or shutil.which("libreoffice")
    )
    return JSONResponse(
        status_code=200,
        content={
            "status": "ready" if pandoc and libreoffice else "degraded",
            "redis": "ok",
            "engines": {"pandoc": bool(pandoc), "libreoffice": bool(libreoffice)},
        },
    )


@app.get("/metrics")
def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
