import argparse
import json
import shutil
import tempfile
from pathlib import Path

from .config import get_settings
from .converter import ConversionEngine
from .errors import ConversionError
from .formats import detect_format, normalize_format
from .security import validate_upload


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert PDF, Word, Markdown, HTML, ODT, RTF and TXT files"
    )
    parser.add_argument("input", type=Path)
    parser.add_argument("--to", required=True, help="pdf/docx/doc/md/html/odt/rtf/txt")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        source = args.input.resolve()
        target = normalize_format(args.to)
        source_format = detect_format(source, source.name)
        settings = get_settings()
        validate_upload(source, source_format, settings)
        with tempfile.TemporaryDirectory(prefix="docconvert-cli-") as temporary:
            result = ConversionEngine(settings).convert(
                source, source_format, target, Path(temporary)
            )
            # Markdown 含抽取图片时引擎返回 ZIP 包，扩展名需按真实格式修正
            destination = args.output
            note = None
            if result.path.suffix.lower() != destination.suffix.lower():
                destination = destination.with_suffix(result.path.suffix)
                note = (
                    f"结果含抽取图片，已打包为 {result.path.suffix.lstrip('.')}；"
                    f"解压后为 document.md 与 assets/"
                )
            if destination.resolve() == source:
                raise ConversionError("OUTPUT_OVERWRITE", "输出文件不能覆盖输入文件", 400)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(result.path, destination)
            payload = {
                "output": str(destination.resolve()),
                "media_type": result.media_type,
                "warnings": result.warnings,
            }
            if note:
                payload["note"] = note
            print(json.dumps(payload, ensure_ascii=False, indent=2))
    except ConversionError as exc:
        parser.exit(1, f"{exc.code}: {exc.message}\n")


if __name__ == "__main__":
    main()
